import {RouterModule, Routes } from '@angular/router';
import { ListealbumComponent } from './listealbum/listealbum.component';
import { AccueilComponent } from './accueil/accueil.component';
import { ListechanteursComponent } from './listechanteurs/listechanteurs.component';
import { DetailalbumComponent } from './detailalbum/detailalbum.component';
import { PlaylistComponent } from './playlist/playlist.component';
import { PlaylistdetailsComponent } from "./playlistdetails/playlistdetails.component" ;

export const appRoutes: Routes = [
    { path: '', component: AccueilComponent },
    { path: 'accueil', component: AccueilComponent },
    { path: 'listealbum', component : ListealbumComponent},
    { path: 'listechanteurs', component : ListechanteursComponent},
    { path: 'cd/:id', component: DetailalbumComponent },
    { path: 'playlist', component: PlaylistComponent },
    { path: 'playlist/:id', component: PlaylistdetailsComponent },
    ]
