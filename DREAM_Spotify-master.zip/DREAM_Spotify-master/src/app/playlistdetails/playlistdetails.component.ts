import { Component, OnInit } from '@angular/core';
import { SpotifyService } from '../spotify.service';
import { ActivatedRoute } from '@angular/router'



@Component({
  selector: 'app-playlistdetails',
  templateUrl: './playlistdetails.component.html',
  styleUrls: ['./playlistdetails.component.css']
})
export class PlaylistdetailsComponent implements OnInit {

  private idPlaylist : string;
  private playlist : Object;
  

  constructor(private spotService : SpotifyService,private route:ActivatedRoute) { }

  ngOnInit() {
    this.spotService.afficherLog();
    this.getTracks();
  }

  getTracks(){
    console.log(this.idPlaylist); 
    this.idPlaylist = this.route.snapshot.params["id"];  
     
    this.spotService.getPlaylistTracks(this.idPlaylist).subscribe(      
        (res) =>{
          this.playlist = res;
          console.log(this.playlist);
        },
        (err) => console.log(err)
      );
  }

  removeTrackPlaylist(position,uri){    
    console.log (" idPlaylist : " + this.idPlaylist +
                "\n position : " + position +
                "\n uri : " + uri );
    //Appel au service pour retirer le morceaux de la playlist            
    this.spotService.removePlaylistTrack(this.idPlaylist,position,uri)
      .subscribe(
        (res) => {
          console.log(res)
          window.location.reload();
        },
        (err) => console.log(err)
      ); 
  }

}


/** A Ajouter dans le remove
  *
  *
  *
"
{
  \"tracks\":
    [
      { 
        \"uri\":\"spotify:track:2DB2zVP1LVu6jjyrvqD44z\"
        ,\"positions\":[0]
      }
      ,{
        \"uri\":\"spotify:track:5ejwTEOCsaDEjvhZTcU6lg\"
        ,\"positions\":[1]
      }
    ]
}" */