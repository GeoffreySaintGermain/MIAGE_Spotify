import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import {SpotifyService } from '../spotify.service';

@Component({
  selector: 'app-detailalbum',
  templateUrl: './detailalbum.component.html',
  styleUrls: ['./detailalbum.component.css']
})
export class DetailalbumComponent implements OnInit {

  //Partie album
  private idalbum: string;
  private album: Object;
 
  //playlists de l'utilisateur
  private playlist : Object[];

  constructor(private route:ActivatedRoute, private spotService : SpotifyService) { }

  ngOnInit() {
    this.idalbum = this.route.snapshot.params["id"];
    this.getAlbumId();
    this.getPlaylist();
  }

  //Récupérer les données d'un album
  getAlbumId(){
    this.spotService.getAlbumId(this.idalbum).subscribe(
      (res) => {
        this.album = res,
        console.log(this.album)
      },
      (error) => console.log(error)
    );
  }

  //récupérer les playlist pour alimenter les listes déroulantes
  getPlaylist(){
    this.spotService.getPlaylist().subscribe(
      (res) => {
        this.playlist = res["items"],
        console.log(res)
      },
      (error) => console.log(error)
    );
  }

  //Ajouter une chanson à une playlist
  addToPlaylist(uri:string, idPlaylist: string){
      console.log("uri " + uri +
                  "\nidPlaylist " + idPlaylist); 

      var track ={"uris":[uri]}
      console.log(track); 

      this.spotService.addToPlaylist(track, idPlaylist);
  }

  

  

}
