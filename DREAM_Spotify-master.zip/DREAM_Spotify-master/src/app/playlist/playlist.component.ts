import { Component, OnInit } from '@angular/core';
import { SpotifyService } from '../spotify.service';

@Component({
  selector: 'app-playlist',
  templateUrl: './playlist.component.html',
  styleUrls: ['./playlist.component.css']
})
export class PlaylistComponent implements OnInit {

  playlist : Object[];

  constructor(private spotService : SpotifyService) { }

  ngOnInit() {
    this.getPlaylist();
  
  }

  //Récupérer les playlists de l'utilisateur
  getPlaylist(){
    this.spotService.getPlaylist().subscribe(
      (res) => {
        this.playlist = res["items"],
        console.log(res)
      },
      (err) => console.log(err)
    );
  }

  //Créer une nouvelle playlist
  addPlaylist(nom : string, description : string, visibilite : string){
    console.log(" nom :" + nom +
                "\n description :" + description +
                "\n publique :" + visibility);
    var visibility = false;
    if(visibilite == "publique")
      visibility = true;

    var playlist={
      "name": nom,
      "description" : description,
      "public" : visibility
    }

    this.spotService.addPlaylist(playlist);
  }

}
