import { Component, OnInit } from '@angular/core';
import { SpotifyService } from '../spotify.service';

@Component({
  selector: 'app-listechanteurs',
  templateUrl: './listechanteurs.component.html',
  styleUrls: ['./listechanteurs.component.css']
})
export class ListechanteursComponent implements OnInit {

  private chanteur : any[];


  constructor(private spotService : SpotifyService) {

   }

  chercherChanteur(motCle : string){
    this.spotService.getChanteur(motCle).subscribe(
      (res) => this.chanteur = res["artists"].items,
      (error) => console.log(error)
    );
  }

  ngOnInit() {
   
  }


}
